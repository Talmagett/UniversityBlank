namespace Lessons.Otus.Scripts.UI
{
    public class EffectPresenter
    {
        private EffectView _effectView;
        private Effect _effect;
        public EffectPresenter(EffectView effectView, Effect effect)
        {
            _effectView = effectView;
            _effect = effect;
        }
    }
}