using System;
using UnityEngine;

namespace Lessons.Otus.Scripts
{
    public sealed class Effect
    {
        public event Action<float> OnValueChanged;
        public float Value { get; private set; }
        public Sprite Icon { get; }
        public Color Color { get; }
    
        public void SetValue(float value)
        {
            this.Value = value;
            this.OnValueChanged?.Invoke(this.Value);
        }
    
        public Effect(int id,float value, Sprite icon, Color color)
        {
            this.Value = value;
            this.Icon = icon;
            this.Color = color;
        }
    }

}